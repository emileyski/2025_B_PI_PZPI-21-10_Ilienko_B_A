import { Card, Row, Col, Typography, List, Tag } from "antd";
import {
    LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, Legend,
} from "recharts";

const statsData = [
    { date: "2024-06-01", growth: 25, watered: 1 },
    { date: "2024-06-02", growth: 35, watered: 0 },
    { date: "2024-06-03", growth: 55, watered: 1 },
    { date: "2024-06-04", growth: 65, watered: 1 },
    { date: "2024-06-05", growth: 80, watered: 0 },
    { date: "2024-06-06", growth: 95, watered: 1 },
];

const pieData = [
    { name: "Healthy", value: 7 },
    { name: "Needs Water", value: 3 },
    { name: "Sick", value: 1 },
];

const COLORS = ["#67c23a", "#e6a23c", "#f56c6c"];

const events = [
    {
        id: 1,
        type: "watering",
        time: "2024-06-06 12:11",
        description: "Plant 'Monstera' was watered",
    },
    {
        id: 2,
        type: "growth",
        time: "2024-06-06 11:30",
        description: "Plant 'Ficus' growth increased to 92%",
    },
    {
        id: 3,
        type: "sensor",
        time: "2024-06-05 22:41",
        description: "Soil moisture dropped below 30% on 'Dieffenbachia'",
    },
    {
        id: 4,
        type: "health",
        time: "2024-06-05 20:11",
        description: "'Dracaena' marked as Sick",
    },
    {
        id: 5,
        type: "watering",
        time: "2024-06-05 18:02",
        description: "Plant 'Cactus' was watered",
    },
];

function eventTag(type: string) {
    switch (type) {
        case "watering": return <Tag color="blue">Watered</Tag>;
        case "growth": return <Tag color="green">Growth</Tag>;
        case "sensor": return <Tag color="orange">Sensor</Tag>;
        case "health": return <Tag color="red">Health</Tag>;
        default: return <Tag>{type}</Tag>;
    }
}

export default function Home() {
    return (
        <>
            <Typography.Title level={2}>Dashboard</Typography.Title>

            <Row gutter={[24, 24]}>
                <Col xs={24} md={12}>
                    <Card title="Plant Growth Over Time" style={{ height: 350 }}>
                        <div style={{ width: "100%", height: 270 }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={statsData}>
                                    <XAxis dataKey="date" />
                                    <YAxis />
                                    <Tooltip />
                                    <Line type="monotone" dataKey="growth" stroke="#1890ff" strokeWidth={2} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </Card>
                </Col>
                <Col xs={24} md={12}>
                    <Card title="Watered/Not Watered (last 6 days)" style={{ height: 350 }}>
                        <div style={{ width: "100%", height: 270 }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={statsData}>
                                    <XAxis dataKey="date" />
                                    <YAxis />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey="watered" fill="#91cc75" name="Watered" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </Card>
                </Col>
            </Row>

            <Row gutter={[24, 24]} style={{ marginTop: 24 }}>
                <Col xs={24} md={8}>
                    <Card title="Plant Health Status" style={{ height: 350 }}>
                        <div style={{ width: "100%", height: 270 }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie
                                        data={pieData}
                                        dataKey="value"
                                        nameKey="name"
                                        cx="50%"
                                        cy="50%"
                                        outerRadius={80}
                                        fill="#8884d8"
                                        label
                                    >
                                        {pieData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                        ))}
                                    </Pie>
                                    <Legend />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    </Card>
                </Col>
                <Col xs={24} md={16}>
                    <Card title="Recent Events" style={{ height: 350, overflow: "auto" }}>
                        <List
                            dataSource={events}
                            renderItem={item => (
                                <List.Item>
                                    <List.Item.Meta
                                        title={
                                            <span>
                                                {eventTag(item.type)}
                                                <span style={{ marginLeft: 8, fontWeight: 500 }}>{item.description}</span>
                                            </span>
                                        }
                                        description={item.time}
                                    />
                                </List.Item>
                            )}
                        />
                    </Card>
                </Col>
            </Row>
        </>
    );
}
