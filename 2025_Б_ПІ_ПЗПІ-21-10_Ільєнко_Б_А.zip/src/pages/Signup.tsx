import { Button, Form, Input, Divider, Typography, Checkbox, Row, Col, message } from 'antd';
import { GoogleOutlined, FacebookOutlined } from '@ant-design/icons';
import { Link } from 'react-router-dom';

export default function Signup() {
  const [form] = Form.useForm();

  const onFinish = (values: {
    firstName: string;
    lastName: string;
    email: string;
    phonse?: string;
    password: string;
    confirm: string;
    agreement: boolean;
  }) => {
    message.success('Регистрация успешна!');
    console.log('Signup values:', values);
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        width: '100vw',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#f7f8fa',
      }}
    >
      <div
        style={{
          maxWidth: 400,
          width: '100%',
          padding: 32,
          boxShadow: '0 4px 24px #eee',
          borderRadius: 16,
          background: '#fff',
        }}
      >
        <Typography.Title level={2} style={{ textAlign: 'center', marginBottom: 32 }}>
          Sign up
        </Typography.Title>
        <Form
          layout="vertical"
          form={form}
          onFinish={onFinish}
          initialValues={{
            agreement: false,
          }}
        >
          <Row gutter={0} style={{ gap: 12 }}>
            <Col flex="1 1 0">
              <Form.Item
                name="firstName"
                label="First Name"
                rules={[{ required: true, message: 'Enter your first name!' }]}
                style={{ marginBottom: 16 }}
              >
                <Input placeholder="Enter first name" autoComplete="given-name" style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col flex="1 1 0">
              <Form.Item
                name="lastName"
                label="Last Name"
                rules={[{ required: true, message: 'Enter your last name!' }]}
                style={{ marginBottom: 16 }}
              >
                <Input placeholder="Enter last name" autoComplete="family-name" style={{ width: '100%' }} />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={0} style={{ gap: 12 }}>
            <Col flex="1 1 0">
              <Form.Item
                name="email"
                label="Email"
                rules={[
                  { required: true, type: 'email', message: 'Enter a valid email!' },
                ]}
                style={{ marginBottom: 16 }}
              >
                <Input placeholder="Enter email" autoComplete="email" style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col flex="1 1 0">
              <Form.Item
                name="phone"
                label="Phone"
                rules={[
                  {
                    required: false,
                    pattern: /^\+?[0-9\- ()]{7,16}$/,
                    message: 'Enter a valid phone number!',
                  },
                ]}
                style={{ marginBottom: 16 }}
              >
                <Input placeholder="Phone" autoComplete="tel" style={{ width: '100%' }} />
              </Form.Item>
            </Col>
          </Row>
          <Form.Item
            name="password"
            label="Password"
            rules={[
              { required: true, message: 'Enter password!' },
              { min: 6, message: 'Password must be at least 6 characters!' },
            ]}
            hasFeedback
          >
            <Input.Password placeholder="Enter password" autoComplete="new-password" />
          </Form.Item>
          <Form.Item
            name="confirm"
            label="Confirm Password"
            dependencies={['password']}
            hasFeedback
            rules={[
              { required: true, message: 'Confirm your password!' },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue('password') === value) {
                    return Promise.resolve();
                  }
                  return Promise.reject(new Error('Passwords do not match!'));
                },
              }),
            ]}
          >
            <Input.Password placeholder="Repeat password" autoComplete="new-password" />
          </Form.Item>
          <Form.Item
            name="agreement"
            valuePropName="checked"
            rules={[
              {
                validator: (_, value) =>
                  value ? Promise.resolve() : Promise.reject(new Error('You must accept the agreement')),
              },
            ]}
            style={{ marginBottom: 8 }}
          >
            <Checkbox>
              I agree with the <a href="#">Terms & Conditions</a>
            </Checkbox>
          </Form.Item>
          <Button type="primary" htmlType="submit" block>
            Sign up
          </Button>
        </Form>
        <Divider>or</Divider>
        <Button
          icon={<GoogleOutlined />}
          style={{ background: '#fff', color: '#444', marginBottom: 8 }}
          block
          onClick={() => alert('Google Signup')}
        >
          Continue with Google
        </Button>
        <Button
          icon={<FacebookOutlined />}
          style={{ background: '#1877F2', color: '#fff' }}
          block
          onClick={() => alert('Facebook Signup')}
        >
          Continue with Facebook
        </Button>
        <div style={{ marginTop: 24, textAlign: 'center' }}>
          Already have an account? <Link to="/login">Login</Link>
        </div>
      </div>
    </div>
  );
}
