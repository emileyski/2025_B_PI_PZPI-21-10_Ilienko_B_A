import { useState, useMemo } from "react";
import { Card, Row, Col, Typography, Tag, List, Space, Divider, Button, Input, Modal, Tooltip, Form, InputNumber } from "antd";
import { BulbOutlined, DashboardOutlined, ExperimentOutlined, EditOutlined, DeleteOutlined, PlusOutlined, SearchOutlined, ExclamationCircleOutlined } from "@ant-design/icons";

// Много моковых растений
const plantList = Array.from({ length: 12 }).map((_, i) => ({
    id: i + 1,
    name: ["Monstera", "Ficus", "Cactus", "Aloe", "Sansevieria", "Dracaena", "Begonia", "Schefflera", "Dieffenbachia", "Peace Lily", "Fern", "Calathea"][i % 12],
    tags: [["shade-tolerant", "indoor"], ["sunny", "indoor"], ["desert", "indoor"], ["succulent"], ["air-purifying"], ["tropical"], ["flowering"], ["bushy"], ["large-leaf"], ["moisture-loving"], ["fern"], ["decorative"]][i % 12],
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    imageUrl: `https://swanhose.com/cdn/shop/articles/water-plant-growth_800x.jpg?v=1683652693`,
    growthPercentage: 40 + Math.round(Math.random() * 60),
    lamps: i % 3 === 0 ? [{ id: 1, name: "Lamp A", lightLevel: 300, spectrum: "Warm", description: "For fast growth" }] : [],
    sensors: [
        ...(i % 2 === 0 ? [{ id: 1, name: "Moisture", type: "moisture", value: 30 + i, unit: "%" }] : []),
        ...(i % 2 === 1 ? [{ id: 2, name: "Temperature", type: "temperature", value: 20 + i, unit: "°C" }] : []),
    ]
}));

function sensorIcon(type: string) {
    switch (type) {
        case "moisture":
            return <ExperimentOutlined style={{ color: "#91cc75" }} />;
        case "temperature":
            return <DashboardOutlined style={{ color: "#1890ff" }} />;
        default:
            return <ExperimentOutlined />;
    }
}

export default function Plants() {
    const [plants, setPlants] = useState(plantList);
    const [search, setSearch] = useState("");
    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const [editPlant, setEditPlant] = useState<{
        id: number;
        name: string;
        tags: string[];
        description: string;
        imageUrl: string;
        growthPercentage: number;
        lamps: Array<{
            id: number;
            name: string;
            lightLevel: number;
            spectrum: string;
            description: string;
        }>;
        sensors: Array<{
            id: number;
            name: string;
            type: string;
            value: number;
            unit: string;
        }>;
    } | null>(null);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const [deletePlant, setDeletePlant] = useState<any | null>(null);

    const [form] = Form.useForm();


    const filteredPlants = useMemo(() => plants.filter(p =>
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.tags.some(t => t.toLowerCase().includes(search.toLowerCase()))
    ), [plants, search]);

    const handleEdit = (values: unknown) => {
        setPlants(ps => ps.map(p => p.id === (values as { id: number }).id ? { ...p, ...(values as typeof p) } : p));
        setEditPlant(null);
    };
    const handleDelete = (id: number) => {
        setPlants(ps => ps.filter(p => p.id !== id));
        setDeletePlant(null);
    };

    return (
        <div>
            <Typography.Title level={2} style={{ marginBottom: 16 }}>My Plants</Typography.Title>

            {/* Toolbar */}
            <div style={{
                marginBottom: 24,
                display: "flex",
                gap: 12,
                alignItems: "center",
                flexWrap: "wrap",
            }}>
                <Input
                    allowClear
                    prefix={<SearchOutlined />}
                    placeholder="Search by name or tag"
                    style={{ width: 260 }}
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                />
                {/* Тут можно добавить фильтры по тегам/лампам */}
                <Button
                    icon={<PlusOutlined />}
                    type="primary"
                    onClick={() => setIsCreateOpen(true)}
                >
                    Add new
                </Button>
            </div>

            <Row gutter={[16, 16]}>
                {filteredPlants.map((plant) => (
                    <Col xs={24} sm={12} md={8} lg={6} xl={6} key={plant.id}>
                        <Card
                            title={
                                <Space>
                                    {plant.name}
                                    <Tag color={plant.growthPercentage > 80 ? "green" : "blue"}>
                                        {plant.growthPercentage}%
                                    </Tag>
                                </Space>
                            }
                            cover={
                                <img
                                    alt={plant.name}
                                    src={plant.imageUrl}
                                    style={{
                                        height: 110,
                                        objectFit: "cover",
                                        borderTopLeftRadius: 8,
                                        borderTopRightRadius: 8
                                    }}
                                />
                            }
                            actions={[
                                <Tooltip title="Edit" key="edit">
                                    <Button icon={<EditOutlined />} size="small" type="link" onClick={() => setEditPlant(plant)} />
                                </Tooltip>,
                                <Tooltip title="Delete" key="delete">
                                    <Button icon={<DeleteOutlined />} size="small" danger type="link" onClick={() => setDeletePlant(plant)} />
                                </Tooltip>,
                            ]}
                            style={{
                                minHeight: 475,
                                maxHeight: 475,
                                display: "flex",
                                flexDirection: "column",
                                borderRadius: 12,
                                boxShadow: "0 4px 16px #ececec"
                            }}
                            bodyStyle={{ padding: 12, flex: 1, display: "flex", flexDirection: "column" }}
                        >
                            <Typography.Paragraph ellipsis={{ rows: 2 }} style={{ marginBottom: 8 }}>
                                {plant.description}
                            </Typography.Paragraph>
                            <Space wrap>
                                {plant.tags.map(tag => (
                                    <Tag key={tag} color="success">{tag}</Tag>
                                ))}
                            </Space>
                            <Divider style={{ margin: "10px 0" }}>Lamps</Divider>
                            {plant.lamps.length > 0 ? (
                                <List
                                    size="small"
                                    dataSource={plant.lamps}
                                    renderItem={lamp => (
                                        <List.Item>
                                            <BulbOutlined style={{ color: "#ffd666" }} /> <b>{lamp.name}</b>
                                            <span style={{ marginLeft: 8, color: "#aaa" }}>({lamp.spectrum})</span>
                                            <span style={{ marginLeft: 8, color: "#888" }}>lvl: {lamp.lightLevel}</span>
                                        </List.Item>
                                    )}
                                />
                            ) : (
                                <Typography.Text type="secondary" style={{ fontSize: 12 }}>No lamps assigned</Typography.Text>
                            )}
                            <Divider style={{ margin: "10px 0" }}>Sensors</Divider>
                            {plant.sensors.length > 0 ? (
                                <List
                                    size="small"
                                    dataSource={plant.sensors}
                                    renderItem={sensor => (
                                        <List.Item>
                                            {sensorIcon(sensor.type)} <b>{sensor.name}</b>
                                            <span style={{ marginLeft: 8, color: "#888" }}>
                                                {sensor.value}{sensor.unit}
                                            </span>
                                        </List.Item>
                                    )}
                                />
                            ) : (
                                <Typography.Text type="secondary" style={{ fontSize: 12 }}>No sensors assigned</Typography.Text>
                            )}
                        </Card>
                    </Col>
                ))}
            </Row>

            {/* Create Plant Modal */}
            <Modal
                open={isCreateOpen}
                title="Add new plant"
                okText="Create"
                cancelText="Cancel"
                onCancel={() => {
                    setIsCreateOpen(false);
                    form.resetFields();
                }}
                onOk={() => {
                    setIsCreateOpen(false);
                    form.resetFields();
                    // ничего не происходит, просто закрываем
                }}
            >
                <Form form={form} layout="vertical">
                    <Form.Item label="Name" name="name" rules={[{ required: true, message: "Please input plant name" }]}>
                        <Input placeholder="Enter plant name" />
                    </Form.Item>
                    <Form.Item label="Description" name="description">
                        <Input.TextArea rows={2} placeholder="Enter description" />
                    </Form.Item>
                    <Form.Item label="Tags (comma separated)" name="tags">
                        <Input placeholder="indoor, cactus, easy-care..." />
                    </Form.Item>
                    <Form.Item label="Growth %" name="growthPercentage" initialValue={50}>
                        <InputNumber min={0} max={100} style={{ width: "100%" }} />
                    </Form.Item>
                    <Form.Item label="Image URL" name="imageUrl">
                        <Input placeholder="https://..." />
                    </Form.Item>
                </Form>
            </Modal>


            {/* Edit Plant Modal */}
            <Modal
                open={!!editPlant}
                title={`Edit plant: ${editPlant?.name}`}
                okText="Save"
                cancelText="Cancel"
                onCancel={() => setEditPlant(null)}
                onOk={() => handleEdit({ ...editPlant, name: editPlant?.name + " (edited)" })}
            >
                <Typography.Text type="secondary">
                    (Для примера: тут могла бы быть форма для редактирования, по нажатию меняет имя)
                </Typography.Text>
            </Modal>

            {/* Delete Plant Modal */}
            <Modal
                open={!!deletePlant}
                title={<span><ExclamationCircleOutlined style={{ color: "red" }} /> Confirm Delete</span>}
                okText="Delete"
                okButtonProps={{ danger: true }}
                cancelText="Cancel"
                onCancel={() => setDeletePlant(null)}
                onOk={() => handleDelete(deletePlant?.id)}
            >
                Are you sure you want to delete <b>{deletePlant?.name}</b>?
            </Modal>
        </div>
    );
}
