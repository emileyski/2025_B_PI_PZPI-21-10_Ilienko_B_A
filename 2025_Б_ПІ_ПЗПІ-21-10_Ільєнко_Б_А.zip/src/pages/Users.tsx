import { useState } from "react";
import {
    Table, Button, Space, Tag, Input, Select, Modal, Typography, Avatar, Tooltip, Row, Col
} from "antd";
import {
    UserOutlined, PlusOutlined, EditOutlined, DeleteOutlined, SearchOutlined, MailOutlined, PhoneOutlined
} from "@ant-design/icons";

const ROLES = [
    { value: "admin", label: "Admin", color: "red" },
    { value: "support", label: "Support", color: "orange" },
    { value: "client", label: "Client", color: "green" }
];

const MOCK_USERS = [
    {
        id: 1,
        name: "Bogdan Ilyenko",
        email: "admin@gmail.com",
        phone: "+380961234567",
        role: "admin",
        status: "active",
    },
    {
        id: 2,
        name: "John Doe",
        email: "john.doe@mail.com",
        phone: "+380501234567",
        role: "client",
        status: "active",
    },
    {
        id: 3,
        name: "Anna Support",
        email: "anna.support@plants.com",
        phone: "+380932223344",
        role: "support",
        status: "suspended",
    },
    {
        id: 4,
        name: "Maksym Manager",
        email: "maks.manager@plants.com",
        phone: "+380678888888",
        role: "client",
        status: "active",
    },
    {
        id: 5,
        name: "Oleg Manager",
        email: "oleg.manager@plants.com",
        phone: "+380999999999",
        role: "support",
        status: "active",
    },
    {
        id: 6,
        name: "Olena Manager",
        email: "oleg.manager@plants.com",
        phone: "+380678888888",
        role: "client",
        status: "suspended",
    },
    {
        id: 5,
        name: "Oleg Manager",
        email: "oleg.manager@plants.com",
        phone: "+380999999999",
        role: "support",
        status: "active",
    },
    {
        id: 6,
        name: "Olena Manager",
        email: "oleg.manager@plants.com",
        phone: "+380678888888",
        role: "client",
        status: "suspended",
    },
    {
        id: 5,
        name: "Oleg Manager",
        email: "oleg.manager@plants.com",
        phone: "+380999999999",
        role: "support",
        status: "active",
    },
    {
        id: 6,
        name: "Olena Manager",
        email: "oleg.manager@plants.com",
        phone: "+380678888888",
        role: "client",
        status: "suspended",
    },
    {
        id: 5,
        name: "Oleg Manager",
        email: "oleg.manager@plants.com",
        phone: "+380999999999",
        role: "support",
        status: "active",
    },
    {
        id: 6,
        name: "Olena Manager",
        email: "oleg.manager@plants.com",
        phone: "+380678888888",
        role: "client",
        status: "suspended",
    }
];

export default function UsersTab() {
    const [search, setSearch] = useState("");
    const [role, setRole] = useState<string | undefined>();
    const [modal, setModal] = useState<{ open: boolean; user?: any }>({ open: false });

    const filtered = MOCK_USERS.filter(
        u =>
            (!search || u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase())) &&
            (!role || u.role === role)
    );

    const columns = [
        {
            title: "",
            dataIndex: "avatar",
            width: 48,
            render: (_: any, record: any) =>
                <Avatar icon={<UserOutlined />} style={{ background: "#91cc75" }}>
                    {record.name[0]}
                </Avatar>
        },
        {
            title: "Name",
            dataIndex: "name",
            render: (name: string) => <b>{name}</b>,
        },
        {
            title: "Email",
            dataIndex: "email",
            render: (email: string) => (
                <Space>
                    <MailOutlined />
                    {email}
                </Space>
            )
        },
        {
            title: "Phone",
            dataIndex: "phone",
            render: (phone: string) => (
                <Space>
                    <PhoneOutlined />
                    {phone}
                </Space>
            )
        },
        {
            title: "Role",
            dataIndex: "role",
            render: (role: string) => {
                const found = ROLES.find(r => r.value === role);
                return <Tag color={found?.color}>{found?.label}</Tag>;
            }
        },
        {
            title: "Status",
            dataIndex: "status",
            render: (status: string) =>
                status === "active"
                    ? <Tag color="green">Active</Tag>
                    : <Tag color="red">Suspended</Tag>
        },
        {
            title: "",
            key: "actions",
            width: 120,
            render: (_: any, user: any) => (
                <Space>
                    <Tooltip title="Edit">
                        <Button icon={<EditOutlined />} type="link" onClick={() => setModal({ open: true, user })} />
                    </Tooltip>
                    <Tooltip title="Delete">
                        <Button icon={<DeleteOutlined />} type="link" danger onClick={() => setModal({ open: true, user: { ...user, deleting: true } })} />
                    </Tooltip>
                </Space>
            )
        }
    ];

    return (
        <div>
            <Row gutter={16} style={{ marginBottom: 18 }}>
                <Col>
                    <Input
                        placeholder="Search by name or email"
                        prefix={<SearchOutlined />}
                        allowClear
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        style={{ width: 220, marginRight: 12 }}
                    />
                </Col>
                <Col>
                    <Select
                        placeholder="Role"
                        allowClear
                        value={role}
                        style={{ width: 120 }}
                        onChange={v => setRole(v)}
                        options={ROLES}
                    />
                </Col>
                <Col flex="auto" style={{ textAlign: "right" }}>
                    <Button type="primary" icon={<PlusOutlined />} onClick={() => setModal({ open: true })}>
                        Add User
                    </Button>
                </Col>
            </Row>
            <Table
                dataSource={filtered}
                columns={columns}
                rowKey="id"
                pagination={{ pageSize: 5 }}
                bordered
                style={{ background: "#fff", borderRadius: 12, boxShadow: "0 2px 10px #f7f7fa" }}
            />
            <UserModal modal={modal} setModal={setModal} />
        </div>
    );
}

// Модалка (заглушка)
function UserModal({ modal, setModal }: any) {
    const { user } = modal;
    return (
        <Modal
            open={modal.open}
            title={
                user?.deleting ? "Delete User" : user
                    ? "Edit User"
                    : "Add User"
            }
            onCancel={() => setModal({ open: false })}
            footer={
                user?.deleting
                    ? [
                        <Button onClick={() => setModal({ open: false })}>Cancel</Button>,
                        <Button type="primary" danger onClick={() => setModal({ open: false })}>Delete</Button>
                    ]
                    : [
                        <Button onClick={() => setModal({ open: false })}>Cancel</Button>,
                        <Button type="primary" onClick={() => setModal({ open: false })}>Save</Button>
                    ]
            }
            destroyOnClose
        >
            {user?.deleting
                ? <Typography.Text type="danger">Are you sure you want to delete user <b>{user.name}</b>?</Typography.Text>
                : (
                    <Typography.Text type="secondary">
                        (Demo: форма не реализована, только UI)
                    </Typography.Text>
                )}
        </Modal>
    );
}
