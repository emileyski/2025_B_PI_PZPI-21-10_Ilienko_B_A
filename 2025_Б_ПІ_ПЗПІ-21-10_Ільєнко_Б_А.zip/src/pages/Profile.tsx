import { useState } from "react";
import {
    Card, Form, Input, Button, Typography, Avatar, Space, Row, Col, Tag, Modal, Select, Divider, Tooltip
} from "antd";
import {
    UserOutlined, EditOutlined, MailOutlined, PhoneOutlined,
    LockOutlined, DollarOutlined, QuestionCircleOutlined
} from "@ant-design/icons";

const BILLING_PLANS = [
    { value: "free", label: "Free", price: "0₴/mo", color: "default", desc: "Basic access, limited plants and sensors" },
    { value: "pro", label: "Pro", price: "249₴/mo", color: "blue", desc: "All features, unlimited plants and lamps" },
    { value: "business", label: "Business", price: "799₴/mo", color: "gold", desc: "Premium support, multiuser, analytics" },
];

// Demo user data
const user = {
    name: "John Doe",
    email: "john.doe@gmail.com",
    phone: "+380501234567",
    role: "client",
    plan: "pro",
    avatar: "",
};

export default function ProfileTab() {
    const [modal, setModal] = useState<{ type?: string, open: boolean }>({ open: false });
    const [form] = Form.useForm();

    // Start with demo data
    const [userData, setUserData] = useState(user);

    // Fake billing plan
    const currentPlan = BILLING_PLANS.find(p => p.value === userData.plan) || BILLING_PLANS[0];

    return (
        <Card style={{ marginTop: 16, maxWidth: 900, margin: "24px auto", borderRadius: 14 }}>
            <Row gutter={[32, 24]}>
                <Col xs={24} md={8} style={{ textAlign: "center" }}>
                    <Avatar size={84} icon={<UserOutlined />} style={{ background: "#91cc75", marginBottom: 8 }}>
                        {userData.name[0]}
                    </Avatar>
                    <Typography.Title level={4} style={{ margin: 0 }}>
                        {userData.name}
                    </Typography.Title>
                    <Tag color="blue" style={{ fontSize: 13 }}>{userData.role.toUpperCase()}</Tag>
                    <div style={{ margin: "8px 0" }}>
                        <MailOutlined /> <span style={{ color: "#888" }}>{userData.email}</span>
                        <br />
                        <PhoneOutlined /> <span style={{ color: "#888" }}>{userData.phone}</span>
                    </div>
                    <Button
                        icon={<EditOutlined />}
                        type="link"
                        onClick={() => setModal({ type: "edit", open: true })}
                        style={{ marginBottom: 8 }}
                    >
                        Edit profile
                    </Button>
                    <Divider />
                    <Space direction="vertical" size="middle" style={{ width: "100%" }}>
                        <Button
                            icon={<LockOutlined />}
                            block
                            onClick={() => setModal({ type: "password", open: true })}
                        >Change password</Button>
                        <Button
                            icon={<DollarOutlined />}
                            block
                            onClick={() => setModal({ type: "billing", open: true })}
                        >Manage billing plan</Button>
                        <Button
                            icon={<QuestionCircleOutlined />}
                            block
                            onClick={() => setModal({ type: "support", open: true })}
                        >Contact support</Button>
                    </Space>
                </Col>
                <Col xs={24} md={16}>
                    <Typography.Title level={5}>Current billing plan:</Typography.Title>
                    <Card
                        bordered={false}
                        style={{ background: "#f7f8fa", borderRadius: 10, marginBottom: 12 }}
                    >
                        <Space>
                            <Tag color={currentPlan.color} style={{ fontSize: 16 }}>{currentPlan.label}</Tag>
                            <span style={{ fontSize: 18, fontWeight: 500 }}>{currentPlan.price}</span>
                        </Space>
                        <div style={{ color: "#888", marginTop: 4 }}>{currentPlan.desc}</div>
                        <Button
                            type="link"
                            style={{ float: "right", marginTop: -30 }}
                            onClick={() => setModal({ type: "billing", open: true })}
                        >Change plan</Button>
                    </Card>
                    <Divider />
                    <Typography.Title level={5}>Quick Actions:</Typography.Title>
                    <Space>
                        <Button type="primary" icon={<EditOutlined />} onClick={() => setModal({ type: "edit", open: true })}>
                            Edit profile
                        </Button>
                        <Button icon={<LockOutlined />} onClick={() => setModal({ type: "password", open: true })}>
                            Change password
                        </Button>
                        <Button icon={<QuestionCircleOutlined />} onClick={() => setModal({ type: "support", open: true })}>
                            Contact support
                        </Button>
                    </Space>
                </Col>
            </Row>

            {/* Edit Profile Modal */}
            <Modal
                open={modal.open && modal.type === "edit"}
                title="Edit Profile"
                onCancel={() => setModal({ open: false })}
                onOk={() => {
                    form.validateFields().then(values => {
                        setUserData({ ...userData, ...values });
                        setModal({ open: false });
                    });
                }}
                okText="Save"
                destroyOnClose
            >
                <Form form={form} layout="vertical" initialValues={userData}>
                    <Form.Item label="Name" name="name" rules={[{ required: true, message: "Name required" }]}>
                        <Input />
                    </Form.Item>
                    <Form.Item label="Email" name="email" rules={[{ type: "email", required: true }]}>
                        <Input />
                    </Form.Item>
                    <Form.Item label="Phone" name="phone">
                        <Input />
                    </Form.Item>
                </Form>
            </Modal>

            {/* Change Password Modal */}
            <Modal
                open={modal.open && modal.type === "password"}
                title="Change Password"
                onCancel={() => setModal({ open: false })}
                okText="Change"
                destroyOnClose
                onOk={() => setModal({ open: false })}
            >
                <Form layout="vertical">
                    <Form.Item label="Current Password" name="current" rules={[{ required: true }]}>
                        <Input.Password />
                    </Form.Item>
                    <Form.Item label="New Password" name="new" rules={[{ required: true }]}>
                        <Input.Password />
                    </Form.Item>
                    <Form.Item label="Confirm New Password" name="confirm" rules={[{ required: true }]}>
                        <Input.Password />
                    </Form.Item>
                </Form>
                <Typography.Text type="secondary">(Mock: форма только для UI, не меняет ничего)</Typography.Text>
            </Modal>

            {/* Billing Modal */}
            <Modal
                open={modal.open && modal.type === "billing"}
                title="Billing Plan"
                onCancel={() => setModal({ open: false })}
                okText="Save"
                destroyOnClose
                onOk={() => setModal({ open: false })}
            >
                <Form layout="vertical" initialValues={{ plan: userData.plan }}>
                    <Form.Item label="Choose plan" name="plan">
                        <Select>
                            {BILLING_PLANS.map(plan =>
                                <Select.Option key={plan.value} value={plan.value}>
                                    <Tag color={plan.color}>{plan.label}</Tag> {plan.price}
                                </Select.Option>
                            )}
                        </Select>
                    </Form.Item>
                </Form>
                <Typography.Text type="secondary">(Mock: только UI, не меняет реальный тариф)</Typography.Text>
            </Modal>

            {/* Support Modal */}
            <Modal
                open={modal.open && modal.type === "support"}
                title="Contact Support"
                onCancel={() => setModal({ open: false })}
                okText="Send"
                destroyOnClose
                onOk={() => setModal({ open: false })}
            >
                <Form layout="vertical">
                    <Form.Item label="Your message" name="message" rules={[{ required: true, message: "Enter your question" }]}>
                        <Input.TextArea rows={4} />
                    </Form.Item>
                </Form>
                <Typography.Text type="secondary">Response will be sent to your email: <b>{userData.email}</b></Typography.Text>
            </Modal>
        </Card>
    );
}
