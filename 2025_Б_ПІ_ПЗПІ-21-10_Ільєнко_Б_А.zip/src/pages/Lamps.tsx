import { useState, useMemo } from "react";
import {
    Tabs, Card, Typography, Tag, Row, Col, Divider, Timeline, Statistic, Space,
    Input, Select, Button, Modal, Pagination, Form, InputNumber, Tooltip
} from "antd";
import {
    BulbOutlined, LineChartOutlined, CheckCircleTwoTone, ClockCircleOutlined,
    EditOutlined, DeleteOutlined, PlusOutlined, SearchOutlined
} from "@ant-design/icons";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as ChartTooltip, Legend } from "recharts";

const SPECTRUMS = ["Warm", "Cool", "Daylight", "Full"];
const PLANTS = ["Monstera", "Aloe", "Ficus", "Cactus", "Sansevieria", "Begonia", "Fern", "Peace Lily"];

const initialLampData = [
    {
        id: 1,
        name: "Lamp A",
        spectrum: "Warm",
        lightLevel: 300,
        power: 20,
        description: "Ideal for tropical plants.",
        plants: ["Monstera", "Aloe"],
        hours: 120,
        active: true,
    },
    {
        id: 2,
        name: "Lamp B",
        spectrum: "Cool",
        lightLevel: 250,
        power: 18,
        description: "Perfect for leafy plants.",
        plants: ["Ficus"],
        hours: 92,
        active: false,
    },
    {
        id: 3,
        name: "Lamp C",
        spectrum: "Daylight",
        lightLevel: 400,
        power: 25,
        description: "Great for succulents and cacti.",
        plants: ["Cactus", "Sansevieria"],
        hours: 154,
        active: true,
    },
    {
        id: 4,
        name: "Lamp D",
        spectrum: "Full",
        lightLevel: 350,
        power: 22,
        description: "Universal lamp for all plants.",
        plants: ["Begonia", "Fern", "Peace Lily"],
        hours: 70,
        active: true,
    },
    {
        id: 5,
        name: "Lamp D",
        spectrum: "Full",
        lightLevel: 350,
        power: 22,
        description: "Universal lamp for all plants.",
        plants: ["Begonia", "Fern", "Peace Lily"],
        hours: 70,
        active: true,
    },
    {
        id: 6,
        name: "Lamp D",
        spectrum: "Full",
        lightLevel: 350,
        power: 22,
        description: "Universal lamp for all plants.",
        plants: ["Begonia", "Fern", "Peace Lily"],
        hours: 70,
        active: true,
    },
    {
        id: 7,
        name: "Lamp D",
        spectrum: "Full",
        lightLevel: 350,
        power: 22,
        description: "Universal lamp for all plants.",
        plants: ["Begonia", "Fern", "Peace Lily"],
        hours: 70,
        active: true,
    },
];

const logs = [
    {
        time: "2024-06-07 15:31",
        lamp: "Lamp A",
        event: "Turned ON automatically by schedule",
        type: "on",
        user: null,
        details: "Scheduled daily ON at 15:30",
    },
    {
        time: "2024-06-07 12:20",
        lamp: "Lamp B",
        event: "Turned OFF (manual)",
        type: "off",
        user: "admin",
        details: "Switched OFF from dashboard",
    },
    {
        time: "2024-06-06 22:10",
        lamp: "Lamp C",
        event: "Brightness adjusted",
        type: "brightness",
        user: "iot-system",
        details: "Light level changed from 200 → 400 due to low light sensor",
    },
    {
        time: "2024-06-06 20:18",
        lamp: "Lamp A",
        event: "Firmware updated",
        type: "update",
        user: "system",
        details: "Version 1.2.5 installed successfully",
    },
    {
        time: "2024-06-06 18:01",
        lamp: "Lamp C",
        event: "Error: Overheating detected",
        type: "error",
        user: null,
        details: "Temperature 87°C. Lamp auto-shutdown for 15 min",
    },
    {
        time: "2024-06-06 16:15",
        lamp: "Lamp D",
        event: "Turned OFF automatically by schedule",
        type: "off",
        user: null,
        details: "Scheduled daily OFF at 16:00",
    },
    {
        time: "2024-06-05 18:50",
        lamp: "Lamp A",
        event: "Reconnected to network",
        type: "network",
        user: null,
        details: "WiFi SSID: Home-IoT, RSSI: -62dBm",
    },
];

const COLORS = ["#91cc75", "#5fb1ef", "#f7ba1e", "#f56c6c",];

function logIcon(type: string) {
    switch (type) {
        case "on": return <BulbOutlined style={{ color: "#91cc75" }} />;
        case "off": return <BulbOutlined style={{ color: "#bfbfbf" }} />;
        case "brightness": return <LineChartOutlined style={{ color: "#5fb1ef" }} />;
        case "error": return <ClockCircleOutlined style={{ color: "#f56c6c" }} />;
        case "update": return <CheckCircleTwoTone twoToneColor="#2db7f5" />;
        case "network": return <ClockCircleOutlined style={{ color: "#e6a23c" }} />;
        default: return <BulbOutlined />;
    }
}

export default function Lamps() {
    const [tabKey, setTabKey] = useState("1");
    const [data, setData] = useState(initialLampData);
    const [search, setSearch] = useState("");
    const [spectrum, setSpectrum] = useState<string | undefined>(undefined);
    const [page, setPage] = useState(1);
    const pageSize = 6;

    const [modal, setModal] = useState<{ type?: "add" | "edit" | "delete"; lamp?: any }>({});

    // Фильтрация и поиск
    const filtered = useMemo(() => data.filter(lamp => {
        return (
            (!search ||
                lamp.name.toLowerCase().includes(search.toLowerCase()) ||
                lamp.description.toLowerCase().includes(search.toLowerCase())
            ) &&
            (!spectrum || lamp.spectrum === spectrum)
        );
    }), [data, search, spectrum]);

    // Пагинация
    const paged = useMemo(
        () => filtered.slice((page - 1) * pageSize, page * pageSize),
        [filtered, page]
    );

    // PieChart data
    const statsData = data.map((lamp, idx) => ({
        name: lamp.name,
        value: lamp.hours,
        color: COLORS[idx % COLORS.length]
    }));

    // CRUD
    function handleAdd(values: any) {
        setData(prev => [
            { ...values, id: Date.now(), hours: 0, active: true },
            ...prev
        ]);
        setModal({});
    }
    function handleEdit(values: any) {
        setData(prev =>
            prev.map(l => l.id === values.id ? { ...l, ...values } : l)
        );
        setModal({});
    }
    function handleDelete(id: number) {
        setData(prev => prev.filter(l => l.id !== id));
        setModal({});
    }

    return (
        <div>
            <Typography.Title level={2} style={{ marginBottom: 16 }}>
                Lamps
            </Typography.Title>
            <Tabs activeKey={tabKey} onChange={setTabKey} items={[
                {
                    key: "1",
                    label: "All Lamps",
                    children: (
                        <>
                            {/* Toolbar */}
                            <div style={{
                                marginBottom: 18,
                                display: "flex",
                                flexWrap: "wrap",
                                gap: 12,
                                alignItems: "center",
                            }}>
                                <Input
                                    placeholder="Search lamps"
                                    prefix={<SearchOutlined />}
                                    allowClear
                                    value={search}
                                    onChange={e => { setSearch(e.target.value); setPage(1); }}
                                    style={{ width: 220 }}
                                />
                                <Select
                                    allowClear
                                    placeholder="Spectrum"
                                    style={{ width: 120 }}
                                    options={SPECTRUMS.map(v => ({ label: v, value: v }))}
                                    value={spectrum}
                                    onChange={v => { setSpectrum(v); setPage(1); }}
                                />
                                <Button
                                    type="primary"
                                    icon={<PlusOutlined />}
                                    onClick={() => setModal({ type: "add" })}
                                >
                                    Add
                                </Button>
                            </div>
                            {/* List */}
                            <Row gutter={[16, 16]}>
                                {paged.map((lamp) => (
                                    <Col xs={24} md={12} lg={8} key={lamp.id}>
                                        <Card
                                            title={
                                                <Space>
                                                    <BulbOutlined />
                                                    {lamp.name}
                                                    <Tag color={lamp.active ? "green" : "red"}>
                                                        {lamp.active ? "Active" : "Off"}
                                                    </Tag>
                                                </Space>
                                            }
                                            extra={<Tag color="blue">{lamp.spectrum}</Tag>}
                                            style={{ borderRadius: 10, minHeight: 250, boxShadow: "0 2px 10px #f0f1f2" }}
                                            actions={[
                                                <Tooltip title="Edit"><EditOutlined onClick={() => setModal({ type: "edit", lamp })} /></Tooltip>,
                                                <Tooltip title="Delete"><DeleteOutlined onClick={() => setModal({ type: "delete", lamp })} /></Tooltip>
                                            ]}
                                        >
                                            <Typography.Paragraph>{lamp.description}</Typography.Paragraph>
                                            <Divider style={{ margin: "8px 0" }}>Details</Divider>
                                            <Space direction="vertical" size={4}>
                                                <div>💡 <b>Light Level:</b> {lamp.lightLevel}</div>
                                                <div>⚡ <b>Power:</b> {lamp.power}W</div>
                                                <div>
                                                    <CheckCircleTwoTone twoToneColor="#52c41a" /> <b>Hours worked:</b> {lamp.hours}
                                                </div>
                                                <div>
                                                    <b>Attached Plants:</b>
                                                    <Space>
                                                        {lamp.plants.length > 0
                                                            ? lamp.plants.map((name: string) => <Tag color="success" key={name}>{name}</Tag>)
                                                            : <Tag>No plants</Tag>
                                                        }
                                                    </Space>
                                                </div>
                                            </Space>
                                        </Card>
                                    </Col>
                                ))}
                            </Row>
                            <div style={{ display: "flex", justifyContent: "center", marginTop: 16, marginBottom: 0 }}>
                                <Pagination
                                    current={page}
                                    pageSize={pageSize}
                                    total={50}
                                    onChange={setPage}
                                    showSizeChanger={false}
                                    hideOnSinglePage
                                />
                            </div>
                            {/* Add Modal */}
                            <LampModal
                                open={modal.type === "add"}
                                onCancel={() => setModal({})}
                                onOk={handleAdd}
                                plants={PLANTS}
                                spectrums={SPECTRUMS}
                                title="Add Lamp"
                            />
                            {/* Edit Modal */}
                            <LampModal
                                open={modal.type === "edit"}
                                onCancel={() => setModal({})}
                                onOk={handleEdit}
                                plants={PLANTS}
                                spectrums={SPECTRUMS}
                                title="Edit Lamp"
                                initial={modal.lamp}
                            />
                            {/* Delete Modal */}
                            <Modal
                                open={modal.type === "delete"}
                                onCancel={() => setModal({})}
                                onOk={() => handleDelete(modal.lamp.id)}
                                okText="Delete"
                                okButtonProps={{ danger: true }}
                                title="Confirm delete"
                            >
                                Delete lamp <b>{modal.lamp?.name}</b>?
                            </Modal>
                        </>
                    ),
                },
                {
                    key: "2",
                    label: "Logs",
                    children: (
                        <Card>
                            <Timeline
                                mode="left"
                                items={logs.map(log => ({
                                    color: log.type === "error" ? "red" : log.type === "on" ? "green" : log.type === "off" ? "gray" : "blue",
                                    label: log.time,
                                    children: (
                                        <div>
                                            <Space align="start">
                                                {logIcon(log.type)}
                                                <span>
                                                    <b>{log.lamp}</b>: {log.event}
                                                    <div style={{ fontSize: 12, color: "#888" }}>
                                                        {log.details}
                                                        {log.user && (
                                                            <span style={{ marginLeft: 8, color: "#1890ff" }}>(by {log.user})</span>
                                                        )}
                                                    </div>
                                                </span>
                                            </Space>
                                        </div>
                                    ),
                                }))}
                            />
                        </Card>
                    ),
                },
                {
                    key: "3",
                    label: "Statistics",
                    children: (
                        <Row gutter={[24, 24]}>
                            <Col xs={24} md={12}>
                                <Card title={<span><LineChartOutlined /> Usage Pie Chart</span>} style={{ minHeight: 340 }}>
                                    <div style={{ width: "100%", height: 220 }}>
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                <Pie
                                                    data={statsData}
                                                    dataKey="value"
                                                    nameKey="name"
                                                    cx="50%"
                                                    cy="50%"
                                                    outerRadius={80}
                                                    fill="#8884d8"
                                                    label
                                                >
                                                    {statsData.map((entry) => (
                                                        <Cell key={entry.name} fill={entry.color} />
                                                    ))}
                                                </Pie>
                                                <ChartTooltip />
                                                <Legend />
                                            </PieChart>
                                        </ResponsiveContainer>
                                    </div>
                                </Card>
                            </Col>
                            <Col xs={24} md={12}>
                                <Card title="Summary" style={{ minHeight: 340 }}>
                                    <Space direction="vertical" size="large" style={{ width: "100%" }}>
                                        <Statistic
                                            title="Total Lamps"
                                            value={data.length}
                                            prefix={<BulbOutlined />}
                                        />
                                        <Statistic
                                            title="Total Hours Worked"
                                            value={data.reduce((acc, l) => acc + l.hours, 0)}
                                            suffix="h"
                                        />
                                        <Statistic
                                            title="Most Active Lamp"
                                            value={data.reduce((a, b) => a.hours > b.hours ? a : b).name}
                                            prefix={<CheckCircleTwoTone twoToneColor="#52c41a" />}
                                        />
                                    </Space>
                                </Card>
                            </Col>
                        </Row>
                    ),
                },
            ]} />
        </div>
    );
}

// --- LampModal Компонент ---

function LampModal({ open, onCancel, onOk, plants, spectrums, title, initial }: any) {
    const [form] = Form.useForm();
    // Для эдита заполним форму
    if (initial) form.setFieldsValue(initial);

    return (
        <Modal
            open={open}
            title={title}
            okText="Save"
            cancelText="Cancel"
            onCancel={onCancel}
            onOk={() => {
                form.validateFields().then(values => {
                    if (initial) values.id = initial.id;
                    onOk({ ...initial, ...values });
                    form.resetFields();
                });
            }}
            destroyOnClose
        >
            <Form form={form} layout="vertical" initialValues={initial}>
                <Form.Item label="Name" name="name" rules={[{ required: true }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Spectrum" name="spectrum" rules={[{ required: true }]}>
                    <Select options={spectrums.map((s: string) => ({ value: s, label: s }))} />
                </Form.Item>
                <Form.Item label="Description" name="description">
                    <Input.TextArea />
                </Form.Item>
                <Form.Item label="Light Level" name="lightLevel" rules={[{ required: true }]}>
                    <InputNumber min={0} max={999} style={{ width: "100%" }} />
                </Form.Item>
                <Form.Item label="Power (W)" name="power" rules={[{ required: true }]}>
                    <InputNumber min={1} max={999} style={{ width: "100%" }} />
                </Form.Item>
                <Form.Item label="Plants" name="plants">
                    <Select mode="multiple" options={plants.map((p: string) => ({ value: p, label: p }))} />
                </Form.Item>
            </Form>
        </Modal>
    );
}
