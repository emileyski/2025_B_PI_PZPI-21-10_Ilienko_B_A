import { Button, Form, Input, Divider, Typography, message } from 'antd';
import { GoogleOutlined, FacebookOutlined } from '@ant-design/icons';
import { Link, useNavigate } from 'react-router-dom';
import { useLoginMutation } from '../api/authApi';

export default function Login() {
  const [login, { isLoading }] = useLoginMutation();
  const navigate = useNavigate();

  const onFinish = async (values: { email: string; password: string }) => {
    try {
      const result = await login(values).unwrap();
      if (result.success) {
        message.success('Logged in!');
        navigate('/'); // или на нужную страницу
      } else {
        message.error(result.error || 'Login failed');
      }
    } catch (e: Error | unknown) {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-expect-error
      message.error(e?.data?.error || 'Login failed');
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        width: '100vw',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#f7f8fa',
      }}
    >
      <div
        style={{
          maxWidth: 360,
          width: '100%',
          padding: 32,
          boxShadow: '0 4px 24px #eee',
          borderRadius: 16,
          background: '#fff',
        }}
      >
        <Typography.Title level={2} style={{ textAlign: 'center', marginBottom: 32 }}>
          Login
        </Typography.Title>
        <Form layout="vertical" onFinish={onFinish}>
          <Form.Item
            name="email"
            label="Email"
            rules={[{ required: true, type: 'email', message: 'Enter a valid email!' }]}
          >
            <Input placeholder="Enter email" autoComplete="email" />
          </Form.Item>
          <Form.Item
            name="password"
            label="Password"
            rules={[{ required: true, message: 'Enter password!' }]}
          >
            <Input.Password placeholder="Enter password" autoComplete="current-password" />
          </Form.Item>
          <Button type="primary" htmlType="submit" block loading={isLoading}>
            Log in
          </Button>
        </Form>
        <Divider>or</Divider>
        <Button
          icon={<GoogleOutlined />}
          style={{ background: '#fff', color: '#444', marginBottom: 8 }}
          block
          onClick={() => message.info('Google Login (not implemented)')}
        >
          Continue with Google
        </Button>
        <Button
          icon={<FacebookOutlined />}
          style={{ background: '#1877F2', color: '#fff' }}
          block
          onClick={() => message.info('Facebook Login (not implemented)')}
        >
          Continue with Facebook
        </Button>
        <div style={{ marginTop: 24, textAlign: 'center' }}>
          Don't have an account? <Link to="/signup">Sign up</Link>
        </div>
      </div>
    </div>
  );
}
