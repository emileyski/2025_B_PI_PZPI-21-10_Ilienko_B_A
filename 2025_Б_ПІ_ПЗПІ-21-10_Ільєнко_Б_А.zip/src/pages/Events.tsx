import { List, Tag, Typography, Card, Space, Tooltip, Avatar, Row, Col, Button } from "antd";
import {
    ClockCircleOutlined, BulbOutlined, FireOutlined, ExperimentOutlined,
    UserOutlined, CheckCircleTwoTone, WarningTwoTone, InfoCircleOutlined, DeleteOutlined, PlusCircleOutlined
} from "@ant-design/icons";

// Моканные события
const EVENTS = [
    {
        time: "2024-06-07 17:13",
        type: "plant",
        title: "Monstera was added",
        user: "admin@gmail.com",
        status: "success",
        details: "New plant added to user collection.",
    },
    {
        time: "2024-06-07 16:59",
        type: "lamp",
        title: "Lamp B turned off",
        user: "system",
        status: "info",
        details: "Lamp turned off manually.",
    },
    {
        time: "2024-06-07 16:45",
        type: "sensor",
        title: "Soil Moisture #2: Low value detected",
        user: null,
        status: "warning",
        details: "Humidity dropped below 20%.",
    },
    {
        time: "2024-06-07 16:33",
        type: "user",
        title: "User Anna Support created",
        user: "admin@gmail.com",
        status: "success",
        details: "Support user invited.",
    },
    {
        time: "2024-06-07 16:17",
        type: "lamp",
        title: "Lamp D firmware updated",
        user: "system",
        status: "success",
        details: "Firmware 1.2.6 installed.",
    },
    {
        time: "2024-06-07 15:49",
        type: "sensor",
        title: "pH Sensor #1: Error",
        user: null,
        status: "error",
        details: "Out of range. Sensor requires attention.",
    },
    {
        time: "2024-06-07 14:21",
        type: "user",
        title: "User Maksym Manager deleted",
        user: "admin@gmail.com",
        status: "error",
        details: "Account removed by admin.",
    },
    {
        time: "2024-06-07 14:11",
        type: "plant",
        title: "Cactus: Growth milestone",
        user: null,
        status: "info",
        details: "Growth reached 90%.",
    },
];

// helper
function typeIcon(type: string) {
    switch (type) {
        case "plant": return <FireOutlined style={{ color: "#67c23a" }} />;
        case "lamp": return <BulbOutlined style={{ color: "#f7ba1e" }} />;
        case "sensor": return <ExperimentOutlined style={{ color: "#5fb1ef" }} />;
        case "user": return <UserOutlined style={{ color: "#91cc75" }} />;
        default: return <InfoCircleOutlined />;
    }
}
function statusTag(status: string) {
    switch (status) {
        case "success": return <Tag color="green">Success</Tag>;
        case "warning": return <Tag color="orange">Warning</Tag>;
        case "error": return <Tag color="red">Error</Tag>;
        case "info": return <Tag color="blue">Info</Tag>;
        default: return null;
    }
}
function statusIcon(status: string) {
    switch (status) {
        case "success": return <CheckCircleTwoTone twoToneColor="#67c23a" />;
        case "warning": return <WarningTwoTone twoToneColor="#f7ba1e" />;
        case "error": return <WarningTwoTone twoToneColor="#f56c6c" />;
        default: return <InfoCircleOutlined style={{ color: "#1890ff" }} />;
    }
}
function userAvatar(user: string | null) {
    if (!user) return <Avatar icon={<UserOutlined />} style={{ background: "#ddd" }} />;
    return <Avatar style={{ background: "#1890ff" }}>{user[0].toUpperCase()}</Avatar>;
}

export default function EventsTab() {
    return (
        <Card style={{ marginTop: 16 }}>
            <Row justify="space-between" align="middle" style={{ marginBottom: 16 }}>
                <Col>
                    <Typography.Title level={3} style={{ margin: 0 }}>Events</Typography.Title>
                </Col>
                <Col>
                    <Tooltip title="For demo: add or delete events manually">
                        <Space>
                            <Button type="dashed" icon={<PlusCircleOutlined />} disabled>
                                Add Event
                            </Button>
                            <Button type="text" icon={<DeleteOutlined />} disabled danger>
                                Delete All
                            </Button>
                        </Space>
                    </Tooltip>
                </Col>
            </Row>
            <List
                itemLayout="horizontal"
                dataSource={EVENTS}
                renderItem={event => (
                    <List.Item>
                        <List.Item.Meta
                            avatar={typeIcon(event.type)}
                            title={
                                <Space>
                                    {statusIcon(event.status)}
                                    <span>{event.title}</span>
                                    {statusTag(event.status)}
                                </Space>
                            }
                            description={
                                <Space direction="vertical" size={2}>
                                    <span>
                                        <ClockCircleOutlined /> {event.time}
                                        {event.user && (
                                            <span style={{ marginLeft: 12 }}>
                                                <UserOutlined /> {event.user}
                                            </span>
                                        )}
                                    </span>
                                    <span style={{ color: "#666" }}>
                                        {event.details}
                                    </span>
                                </Space>
                            }
                        />
                    </List.Item>
                )}
            />
        </Card>
    );
}
