import { Outlet } from "react-router-dom";
import { Navbar } from "../components/Navbar";

export default function Dashboard() {
    return (
        <div>
            <Navbar />
            <div style={{ margin: "32px auto", padding: 24, height: 'calc(100vh - 100px)', overflowY: 'auto' }}>
                <Outlet />
            </div>
        </div>
    );
}
