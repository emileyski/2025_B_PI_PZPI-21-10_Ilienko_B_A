import { useState, useMemo } from "react";
import {
    Card, Typography, Tag, Row, Col, Space, Input, Select, Badge, Button, Modal, Progress, Tooltip, List, Tabs
} from "antd";
import {
    FireOutlined, CloudOutlined, BulbOutlined, ExperimentOutlined,
    WarningTwoTone, InfoCircleOutlined, SearchOutlined, HistoryOutlined, CheckCircleTwoTone
} from "@ant-design/icons";

// --- Mock data

const SENSOR_TYPES = [
    { key: "temperature", label: "Temperature", icon: <FireOutlined /> },
    { key: "humidity", label: "Humidity", icon: <CloudOutlined /> },
    { key: "light", label: "Light", icon: <BulbOutlined /> },
    { key: "ph", label: "pH", icon: <ExperimentOutlined /> },
];

const STATUSES = [
    { key: "ok", label: "OK", color: "green" },
    { key: "warning", label: "Warning", color: "orange" },
    { key: "error", label: "Error", color: "red" },
];

const SENSORS = [
    {
        id: 1,
        name: "Soil Temp #1",
        type: "temperature",
        value: 23,
        unit: "°C",
        status: "ok",
        plants: ["Monstera", "Aloe"],
        updated: "2024-06-07 14:10",
        history: [22, 23, 23, 22, 23],
    },
    {
        id: 2,
        name: "Air Humidity #1",
        type: "humidity",
        value: 37,
        unit: "%",
        status: "warning",
        plants: ["Monstera"],
        updated: "2024-06-07 14:09",
        history: [44, 41, 39, 38, 37],
    },
    {
        id: 3,
        name: "Main Light #1",
        type: "light",
        value: 430,
        unit: "lx",
        status: "ok",
        plants: ["Ficus", "Sansevieria"],
        updated: "2024-06-07 14:13",
        history: [380, 410, 430, 420, 430],
    },
    {
        id: 4,
        name: "pH Sensor #1",
        type: "ph",
        value: 5.5,
        unit: "",
        status: "error",
        plants: ["Aloe"],
        updated: "2024-06-07 14:12",
        history: [6.5, 6.0, 5.8, 5.5, 5.5],
    },
    {
        id: 5,
        name: "Soil Moisture #2",
        type: "humidity",
        value: 15,
        unit: "%",
        status: "error",
        plants: ["Cactus"],
        updated: "2024-06-07 14:14",
        history: [21, 19, 18, 15, 15],
    },
    {
        id: 6,
        name: "Air Temp #2",
        type: "temperature",
        value: 29,
        unit: "°C",
        status: "ok",
        plants: ["Cactus", "Ficus"],
        updated: "2024-06-07 14:15",
        history: [28, 28, 29, 29, 29],
    },
];

const SENSOR_LOGS = [
    {
        time: "2024-06-07 14:12",
        sensor: "pH Sensor #1",
        type: "error",
        event: "Sensor error: Out of range",
        value: "5.5",
    },
    {
        time: "2024-06-07 14:14",
        sensor: "Soil Moisture #2",
        type: "error",
        event: "Low soil moisture",
        value: "15%",
    },
    {
        time: "2024-06-07 14:10",
        sensor: "Soil Temp #1",
        type: "ok",
        event: "Normal temperature",
        value: "23°C",
    },
    {
        time: "2024-06-07 14:13",
        sensor: "Main Light #1",
        type: "ok",
        event: "Light level adjusted",
        value: "430lx",
    },
    {
        time: "2024-06-07 14:09",
        sensor: "Air Humidity #1",
        type: "warning",
        event: "Low air humidity",
        value: "37%",
    },
    {
        time: "2024-06-07 14:15",
        sensor: "Air Temp #2",
        type: "ok",
        event: "Temperature normal",
        value: "29°C",
    },
];

// --- UI helpers

function typeIcon(type: string) {
    switch (type) {
        case "temperature": return <FireOutlined style={{ color: "#f56c6c" }} />;
        case "humidity": return <CloudOutlined style={{ color: "#5fb1ef" }} />;
        case "light": return <BulbOutlined style={{ color: "#f7ba1e" }} />;
        case "ph": return <ExperimentOutlined style={{ color: "#67c23a" }} />;
        default: return <InfoCircleOutlined />;
    }
}
function statusTag(status: string) {
    const map: any = { ok: "green", warning: "orange", error: "red" };
    return <Tag color={map[status] || "blue"}>{status.toUpperCase()}</Tag>;
}
function statusBadge(status: string) {
    const map: any = { ok: "success", warning: "warning", error: "error" };
    return <Badge status={map[status] || "default"} />;
}
function logIcon(type: string) {
    if (type === "error") return <WarningTwoTone twoToneColor="#f56c6c" />;
    if (type === "warning") return <InfoCircleOutlined style={{ color: "#e6a23c" }} />;
    return <CheckCircleTwoTone twoToneColor="#52c41a" />;
}

// --- Main

export default function Sensors() {
    const [search, setSearch] = useState("");
    const [typeFilter, setTypeFilter] = useState<string | undefined>();
    const [statusFilter, setStatusFilter] = useState<string | undefined>();
    const [modal, setModal] = useState<{ open: boolean, sensor?: any }>({ open: false });

    const filtered = useMemo(() => SENSORS.filter(s =>
        (!search || s.name.toLowerCase().includes(search.toLowerCase())) &&
        (!typeFilter || s.type === typeFilter) &&
        (!statusFilter || s.status === statusFilter)
    ), [search, typeFilter, statusFilter]);

    return (
        <div>
            <Typography.Title level={2}>Sensors</Typography.Title>
            <Tabs
                defaultActiveKey="1"
                items={[
                    {
                        key: "1",
                        label: "Sensors",
                        children: (
                            <>
                                <Row gutter={16} style={{ marginBottom: 18 }}>
                                    <Col xs={24} md={16} style={{ marginBottom: 8 }}>
                                        <Input
                                            placeholder="Search sensors"
                                            prefix={<SearchOutlined />}
                                            allowClear
                                            value={search}
                                            onChange={e => setSearch(e.target.value)}
                                            style={{ width: 220, marginRight: 12 }}
                                        />
                                        <Select
                                            placeholder="Type"
                                            allowClear
                                            style={{ width: 120, marginRight: 12 }}
                                            value={typeFilter}
                                            onChange={v => setTypeFilter(v)}
                                            options={SENSOR_TYPES.map(st => ({ value: st.key, label: st.label }))}
                                        />
                                        <Select
                                            placeholder="Status"
                                            allowClear
                                            style={{ width: 120 }}
                                            value={statusFilter}
                                            onChange={v => setStatusFilter(v)}
                                            options={STATUSES.map(st => ({ value: st.key, label: st.label }))}
                                        />
                                    </Col>
                                    <Col xs={24} md={8} style={{ textAlign: "right" }}>
                                        <Tooltip title="History only works for demo sensors :)">
                                            <Button icon={<HistoryOutlined />} disabled>
                                                View All History
                                            </Button>
                                        </Tooltip>
                                    </Col>
                                </Row>
                                <Row gutter={[16, 16]}>
                                    {filtered.map(sensor => (
                                        <Col xs={24} sm={12} md={8} xl={6} key={sensor.id}>
                                            <Card
                                                bordered
                                                style={{
                                                    borderRadius: 12,
                                                    boxShadow: "0 2px 12px #f7f7fa",
                                                    minHeight: 320,
                                                    maxHeight: 320,
                                                    display: "flex",
                                                    flexDirection: "column",
                                                    justifyContent: "space-between"
                                                }}
                                                bodyStyle={{ height: "100%", display: "flex", flexDirection: "column", justifyContent: "space-between" }}
                                                actions={[
                                                    <Button
                                                        type="link"
                                                        icon={<HistoryOutlined />}
                                                        size="small"
                                                        onClick={() => setModal({ open: true, sensor })}
                                                        key="history"
                                                    >History</Button>
                                                ]}
                                                cover={sensor.status === "error" ? (
                                                    <div style={{
                                                        background: "#fff2f0", color: "#f56c6c",
                                                        padding: 12, textAlign: "center"
                                                    }}>
                                                        <WarningTwoTone twoToneColor="#f56c6c" /> Alert: Sensor Error!
                                                    </div>
                                                ) : null}
                                            >
                                                <Space align="center" size="large" style={{ marginBottom: 6 }}>
                                                    {statusBadge(sensor.status)}
                                                    {typeIcon(sensor.type)}
                                                    <b>{sensor.name}</b>
                                                    {statusTag(sensor.status)}
                                                </Space>
                                                <div style={{ margin: "12px 0" }}>
                                                    <Typography.Text strong>
                                                        Value: <span style={{ fontSize: 22 }}>{sensor.value}{sensor.unit}</span>
                                                    </Typography.Text>
                                                </div>
                                                <div style={{ marginBottom: 4 }}>
                                                    <span style={{ color: "#aaa" }}>Last updated: {sensor.updated}</span>
                                                </div>
                                                <div>
                                                    <b>Plants:</b>
                                                    <Space>
                                                        {sensor.plants.map((p: string) => <Tag color="success" key={p}>{p}</Tag>)}
                                                    </Space>
                                                </div>
                                                <Progress
                                                    percent={calcProgress(sensor)}
                                                    size="small"
                                                    status={sensor.status === "error" ? "exception" : sensor.status === "warning" ? "active" : "normal"}
                                                    showInfo={false}
                                                    style={{ marginTop: 12 }}
                                                />
                                            </Card>
                                        </Col>
                                    ))}
                                </Row>
                                <SensorHistoryModal modal={modal} setModal={setModal} />
                            </>
                        )
                    },
                    {
                        key: "2",
                        label: "Logs",
                        children: (
                            <Card style={{ marginTop: 16 }}>
                                <Typography.Title level={4} style={{ marginBottom: 16 }}>Sensor Events</Typography.Title>
                                <List
                                    dataSource={SENSOR_LOGS}
                                    renderItem={log => (
                                        <List.Item>
                                            <List.Item.Meta
                                                avatar={logIcon(log.type)}
                                                title={<span><b>{log.sensor}</b> - {log.event}</span>}
                                                description={
                                                    <Space>
                                                        <Tag color="blue">{log.time}</Tag>
                                                        <span>Value: <b>{log.value}</b></span>
                                                        {log.type === "error"
                                                            ? <Tag color="red">Error</Tag>
                                                            : log.type === "warning"
                                                                ? <Tag color="orange">Warning</Tag>
                                                                : <Tag color="green">OK</Tag>
                                                        }
                                                    </Space>
                                                }
                                            />
                                        </List.Item>
                                    )}
                                />
                            </Card>
                        )
                    }
                ]}
            />
        </div>
    );
}

// Helper для прогресс-бара по типу сенсора
function calcProgress(sensor: any) {
    switch (sensor.type) {
        case "temperature":
            return Math.min(Math.max((sensor.value - 10) * 5, 0), 100);
        case "humidity":
            return Math.min(Math.max(sensor.value, 0), 100);
        case "light":
            return Math.min(sensor.value / 6, 100);
        case "ph":
            return Math.min(Math.abs((sensor.value - 4) * 25), 100);
        default:
            return 50;
    }
}

// Модалка истории
function SensorHistoryModal({ modal, setModal }: any) {
    const { sensor } = modal;
    return (
        <Modal
            open={modal.open}
            title={sensor ? `History for ${sensor.name}` : "History"}
            onCancel={() => setModal({ open: false })}
            footer={null}
            width={440}
            destroyOnClose
        >
            {sensor && (
                <>
                    <Typography.Text type="secondary">
                        Last 5 values:
                    </Typography.Text>
                    <div style={{ margin: "12px 0", fontSize: 18 }}>
                        {sensor.history.map((v: any, i: number) =>
                            <span key={i} style={{
                                marginRight: 10,
                                color: i === sensor.history.length - 1 ? "#1890ff" : "#888"
                            }}>{v}{sensor.unit}</span>
                        )}
                    </div>
                    <Typography.Text>
                        <InfoCircleOutlined /> Sensor status: <b>{sensor.status.toUpperCase()}</b>
                    </Typography.Text>
                </>
            )}
        </Modal>
    );
}
