import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const authApi = createApi({
    reducerPath: 'authApi',
    baseQuery: fetchBaseQuery({
        baseUrl: 'http://localhost:3000/api/auth',
        credentials: 'include', // !!! Для работы сессий через cookie
    }),
    endpoints: (builder) => ({
        login: builder.mutation<{
            error: string; success: boolean, user: any
        }, { email: string; password: string }>(
            {
                query: (body) => ({
                    url: '/login',
                    method: 'POST',
                    body,
                }),
            }
        ),
        signup: builder.mutation<{ success: boolean, user: any }, { email: string; password: string; firstName: string; lastName: string; phone?: string }>(
            {
                query: (body) => ({
                    url: '/signup',
                    method: 'POST',
                    body,
                }),
            }
        ),
        logout: builder.mutation<{ success: boolean }, void>(
            {
                query: () => ({
                    url: '/logout',
                    method: 'POST',
                }),
            }
        ),
        getMe: builder.query<any, void>({
            query: () => ({
                url: '/me',
                method: 'GET',
            }),
        }),
    }),
});

export const {
    useLoginMutation,
    useSignupMutation,
    useLogoutMutation,
    useGetMeQuery,
} = authApi;
