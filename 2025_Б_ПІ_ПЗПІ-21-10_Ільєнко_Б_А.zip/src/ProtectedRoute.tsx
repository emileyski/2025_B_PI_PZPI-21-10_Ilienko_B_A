// ProtectedRoute.tsx
import { useGetMeQuery } from './api/authApi';
import { Navigate, useLocation } from 'react-router-dom';

export function ProtectedRoute({ children }: { children: React.ReactNode }) {
    const { error, isLoading } = useGetMeQuery();
    const location = useLocation();

    if (isLoading) return <div>Loading...</div>;
    if (error && 'status' in error && error.status === 401) {
        return <Navigate to="/login" state={{ from: location }} replace />;
    }

    return children;
}
