import { createBrowserRouter, RouterProvider, } from "react-router-dom";
import { Suspense, lazy } from "react";
import { ProtectedRoute } from './ProtectedRoute';
import Dashboard from "./pages/Dashboard";

// Lazy load
const Login = lazy(() => import('./pages/Login'));
const Signup = lazy(() => import('./pages/Signup'));

const Home = lazy(() => import('./pages/Home'));
// const Plants = () => <div>Plants List</div>;
const Plants = lazy(() => import('./pages/Plants'));
// const Lamps = () => <div>Lamps List</div>;
const Lamps = lazy(() => import('./pages/Lamps'));
// const Sensors = () => <div>Sensors List</div>;
const Sensors = lazy(() => import('./pages/Sensors'));
const Users = lazy(() => import('./pages/Users'));
const Events = lazy(() => import('./pages/Events'));
const Profile = lazy(() => import('./pages/Profile'));

const router = createBrowserRouter([
  {
    path: "/",
    element: (
      <ProtectedRoute>
        <Dashboard />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: <Home /> }, // по умолчанию "/"
      { path: "plants", element: <Plants /> },
      { path: "lamps", element: <Lamps /> },
      { path: "sensors", element: <Sensors /> },
      { path: "users", element: <Users /> },
      { path: "events", element: <Events /> },
      { path: "profile", element: <Profile /> },
    ]
  },
  {
    path: "/login",
    element: (
      <Suspense fallback={<div>Loading...</div>}>
        <Login />
      </Suspense>
    ),
  },
  {
    path: "/signup",
    element: (
      <Suspense fallback={<div>Loading...</div>}>
        <Signup />
      </Suspense>
    ),
  },
]);

export const AppRouter: React.FC = () => {
  return <RouterProvider router={router} />;
};
