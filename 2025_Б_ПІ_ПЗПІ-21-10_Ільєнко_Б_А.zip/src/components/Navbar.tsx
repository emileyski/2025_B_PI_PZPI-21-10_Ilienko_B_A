import { Layout, Menu, Button, Space, Dropdown, Typography } from 'antd';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useGetMeQuery, useLogoutMutation } from '../api/authApi';
import { UserOutlined, LogoutOutlined, LoginOutlined, ProfileOutlined } from '@ant-design/icons';

const { Header } = Layout;

export function Navbar() {
    const { data: user, isLoading } = useGetMeQuery();
    const [logout] = useLogoutMutation();
    const navigate = useNavigate();
    const location = useLocation();

    const handleLogout = async () => {
        await logout().unwrap();
        navigate('/login');
    };

    const menuItems = [
        { label: <Link to="/">Home</Link>, key: "home" },
        { label: <Link to="/plants">Plants</Link>, key: "plants" },
        { label: <Link to="/lamps">Lamps</Link>, key: "lamps" },
        { label: <Link to="/sensors">Sensors</Link>, key: "sensors" },
        { label: <Link to="/users">Users</Link>, key: "users" },
        { label: <Link to="/events">Events</Link>, key: "events" },
    ];

    return (
        <Header style={{ background: '#fff', padding: 0, boxShadow: '0 2px 8px #f0f1f2' }}>
            <div style={{
                maxWidth: 1200, margin: '0 auto', display: 'flex',
                alignItems: 'center', height: '100%'
            }}>
                <Typography.Title level={4} style={{ margin: '0 24px 0 0' }}>
                    <Link to="/" style={{ color: '#1890ff', textDecoration: 'none' }}>🌱 PlantsApp</Link>
                </Typography.Title>
                <Menu
                    mode="horizontal"
                    selectedKeys={[location.pathname.split('/')[1] || 'home']}
                    items={menuItems}
                    style={{ flex: 1, borderBottom: 'none', minWidth: 400 }}
                />
                <Space style={{ marginRight: 24 }}>
                    {!isLoading && !user && (
                        <>
                            <Button icon={<LoginOutlined />} type="primary" onClick={() => navigate('/login')}>Login</Button>
                            <Button onClick={() => navigate('/signup')}>Sign Up</Button>
                        </>
                    )}
                    {!isLoading && user && (
                        <Dropdown
                            menu={{
                                items: [
                                    {
                                        label: (
                                            <span
                                                style={{ display: "flex", alignItems: "center" }}
                                                onClick={() => navigate('/profile')}
                                            >
                                                <ProfileOutlined /> <span style={{ marginLeft: 8 }}>Profile</span>
                                            </span>
                                        ),
                                        key: "profile",
                                    },
                                    { type: 'divider' as const },
                                    {
                                        label: (
                                            <span
                                                style={{ display: "flex", alignItems: "center" }}
                                                onClick={handleLogout}
                                            >
                                                <LogoutOutlined /> <span style={{ marginLeft: 8 }}>Logout</span>
                                            </span>
                                        ),
                                        key: "logout",
                                    },
                                ]
                            }}
                            placement="bottomRight"
                            trigger={['click']}
                        >
                            <Button icon={<UserOutlined />} style={{ fontWeight: 'bold' }}>
                                {user.firstName}
                            </Button>
                        </Dropdown>
                    )}
                </Space>
            </div>
        </Header>
    );
}
